<template id="friends">
	<div class="friends_box">
		<div class="friend_header">
			<router-link to="/me/friendsCount">以下是我关注的朋友，猜猜TA是谁？</router-link>
		</div>
		<div class="friends_mood">
			<img class="friendHeaderImg" src="../images/13.jpg" alt="">
			<div class="friendState">
				<span class="mood_state">一般</span>
				<p class="mood_text">以下是我关注的朋友，猜猜TA是谁以下是我关注的朋友，猜猜TA是谁以下是我关注的朋友，猜猜TA是谁以下是我关注的朋友，猜猜TA是谁</p>
				<ul class="friendImgList">
					<li><img src="../images/imglist1.jpg" alt=""></li>
					<li><img src="../images/imglist2.jpg" alt=""></li>
					<li><img src="../images/imglist3.jpg" alt=""></li>
				</ul>
				<div class="friendsLoc">聚光中心</div>
				<div class="stateBottom">
					<div class="time">5月21日 11:00</div>
					<div class="time_right">
						<span class="frined_zan">0</span>
						<img class="time_rightimg1" src="../images/list_dianz_nor.png" alt="" style="width: 26px">
						<span class="frined_com">0</span>
						<img class="time_rightimg2" src="../images/comments.png" alt="" style="width: 20px">
					</div>
				</div>

				<div class="commont_box">
					<div class="arrow"></div>
					<div class="friend_commont">
						<span class="name">小王:</span>
						<span class="commont">下雨天和睡觉更配哦...</span>
					</div>
					<div class="me_commont">
						<span class="name">欧阳</span>  回复  <span class="name">小王:</span><span class="commont">英雄所见略同啊...</span>
					</div>
					<div class="friend_commont">
						<span class="name">丫丫:</span>
						<span class="commont">每天早上都在和床做斗争，唉</span>
					</div>
					<div class="me_commont">
						<span class="name">欧阳</span>  回复  <span class="name">丫丫:</span><span class="commont">哈哈</span>
					</div>
				</div>
			</div>
		</div>
		<div class="friends_mood">
			<img class="friendHeaderImg" src="../images/13.jpg" alt="">
			<div class="friendState">
				<span class="mood_state">一般</span>
				<p class="mood_text">以下是我关注的朋友，猜猜TA是谁以下是我关注的朋友，猜猜TA是谁以下是我关注的朋友，猜猜TA是谁以下是我关注的朋友，猜猜TA是谁</p>
				<ul class="friendImgList">
					<li><img src="../images/imglist1.jpg" alt=""></li>
					<li><img src="../images/imglist2.jpg" alt=""></li>
					<li><img src="../images/imglist3.jpg" alt=""></li>
				</ul>
				<div class="friendsLoc">聚光中心</div>
				<div class="stateBottom">
					<div class="time">5月21日 11:00</div>
					<div class="time_right">
						<span class="frined_zan">0</span>
						<img class="time_rightimg1" src="../images/list_dianz_nor.png" alt="" style="width: 26px">
						<span class="frined_com">0</span>
						<img class="time_rightimg2" src="../images/comments.png" alt="" style="width: 20px">
					</div>
				</div>

				<div class="commont_box">
					<div class="arrow"></div>
					<div class="friend_commont">
						<span class="name">小王:</span>
						<span class="commont">下雨天和睡觉更配哦...</span>
					</div>
					<div class="me_commont">
						<span class="name">欧阳</span>  回复  <span class="name">小王:</span><span class="commont">英雄所见略同啊...</span>
					</div>
					<div class="friend_commont">
						<span class="name">丫丫:</span>
						<span class="commont">每天早上都在和床做斗争，唉</span>
					</div>
					<div class="me_commont">
						<span class="name">欧阳</span>  回复  <span class="name">丫丫:</span><span class="commont">哈哈</span>
					</div>
				</div>
			</div>
		</div>


	</div>
</template>

<script type="text/javascript">
	var friends={
		template:'#friends'
	}
	module.exports=friends
</script>
