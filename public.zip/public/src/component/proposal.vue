<template id="proposal">
    <div >
        <div class="feedback">
            <textarea placeholder="你好，我是产品经理小珺，欢迎给我们提出产品的使用感受和建议！" />
            <span>不少于8字!</span>
        </div>
        <div class="feedback_btn">
            <a class="weui-btn weui-btn_primary">提交</a>
        </div>




    </div>
</template>
<script type="text/javascript">
    var proposal={
        template:'#proposal'
    }
    module.exports=proposal
</script>


