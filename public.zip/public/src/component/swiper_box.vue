<template id="swiper_box" >
	<div class="swiper_box" @click = "bgClick()" v-if="bgflag">
		<div id="bg_back" >
			<div class="swiper-container clickBox">
				<div class="swiper-wrapper">
					<div class="swiper-slide">
						<img src="../images/bg_mood_01.png" alt="" />
						<div class="clickBox_time">
							<span>4月13日</span><span>星期1</span><span>08:20:40</span>
							<div class="clickBox_bottom">今天很高兴今天很高兴今天很高兴今天很高兴今天很高兴</div>
						</div>
					</div>
					<div class="swiper-slide">
						<img src="../images/bg_mood_02.png" alt="" />
						<div class="clickBox_time">
							<span>4月13日</span><span>星期2</span><span>08:20:40</span>
							<div class="clickBox_bottom">今天很高兴今天很高兴今天很高兴今天很高兴今天很高兴今天很高兴今天很高兴天很高兴</div>
						</div>
					</div>
					<div class="swiper-slide">
						<img src="../images/bg_mood_04.png" alt="" />
						<div class="clickBox_time">
							<span>4月13日</span><span>星期</span><span>08:20:40</span>
							<div class="clickBox_bottom">今天很高兴今天很高兴今天很高兴今天很高兴今天很高兴今天很高兴今天很高兴天很高兴</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>

</template>

<script>
    import Swiper from "../js/swiper-3.4.2.min"
    var swiper_box ={
        template:"#swiper_box"
    }
    export default {
        data() {
            return {
                bgflag:true
            }
        },
        mounted(){
            console.log('挂载好了')
            var mySwiper = new Swiper('.swiper-container', {
                direction: 'horizontal',
                loop: true
            })
		},
		methods:{
            bgClick:function () {
				this.showFlag = false
            }
		}
    }


</script>


<style>
	.swiper_box{

		position: absolute;
		top:25%;
		left:50%;
		margin-left: -100px;
	}
	#bg_back{
		position:fixed;
		top: 0;left: 0;
		background: rgba(0,0,0,0.5);
		height:100%;width:100%;
		z-index:100;
	}
	.clickBox {
		width: 100%;
		text-align: center;
		z-index:100;
		border-radius: 10px;
		position: absolute;
		top:30%;
		font-size: 18px;
		color: #666666;
		height:auto;
	}
	.clickBox img{
		width:90%;
		height:auto;
	}


	.clickBox_time {
		position: absolute;
		bottom: 5%;
		width: 90%;
		height: 30%;
		left: 50%;
		margin-left: -50%;
	}

	.clickBox_time span {
		font-size: 12px;
		color: #999999;
		margin: 0 5px;
		line-height: 22px;
	;
	}

	.clickBox_bottom {
		font-size: 13px;
		color: #333333;
		line-height: 20px;
		padding: 0 36px;
		overflow: auto;
		height: 36px;


	}
</style>