<template id="privacy">
    <div class="top20_box" >
        <div class="privacy">
            <span>不看好友的心情记录</span>
            <input type="checkbox" class="weui-switch switchFlag">
        </div>
        <div class="privacy">
            <span>不让好友看我的心情记录</span>
            <input type="checkbox" class="weui-switch switchFlag">
        </div>
    </div>
</template>
<script type="text/javascript">
    var privacy={
        template:'#privacy'
    }
    module.exports=privacy
</script>


