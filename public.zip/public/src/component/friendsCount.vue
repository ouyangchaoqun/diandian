<template id="friendsCount">
    <div >
        <div class="weui-cells friendsCount_box">
            <span class="friendsCount_cell">A</span>
            <a href="" class="weui-cell weui-cell_access">
                <div class="weui-cell__hd">
                    <img class="img_frinedsCount" src="../images/13.jpg" alt="">
                </div>
                <div class="weui-cell__bd name_friendsCount">阿龙</div>
                <div class="weui-cell__ft"></div>
            </a>
            <a href="" class="weui-cell weui-cell_access">
                <div class="weui-cell__hd">
                    <img class="img_frinedsCount" src="../images/13.jpg" alt="">
                </div>
                <div class="weui-cell__bd name_friendsCount">阿龙</div>
                <div class="weui-cell__ft"></div>
            </a>

        </div>
        <div class="weui-cells friendsCount_box">
            <span class="friendsCount_cell">A</span>
            <a href="" class="weui-cell weui-cell_access">
                <div class="weui-cell__hd">
                    <img class="img_frinedsCount" src="../images/13.jpg" alt="">
                </div>
                <div class="weui-cell__bd name_friendsCount">阿龙</div>
                <div class="weui-cell__ft"></div>
            </a>
            <a href="" class="weui-cell weui-cell_access">
                <div class="weui-cell__hd">
                    <img class="img_frinedsCount" src="../images/13.jpg" alt="">
                </div>
                <div class="weui-cell__bd name_friendsCount">阿龙</div>
                <div class="weui-cell__ft"></div>
            </a>

        </div>
        
    </div>
</template>
<script type="text/javascript">
    var friendsCount={
        template:'#friendsCount'
    }
    module.exports=friendsCount
</script>


